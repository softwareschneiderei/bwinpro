/*
 * StandChangeListener.java
 *
 * Created on 18. Mai 2006, 13:05
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package treegross.base;

/**
 *
 * @author jhansen
 */
public interface StandChangeListener {    
    public void StandChanged(StandChangeEvent sce);    
}
