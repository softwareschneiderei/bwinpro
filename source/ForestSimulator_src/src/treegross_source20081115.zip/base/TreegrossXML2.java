/* 
* @(#) TreegrossXML2.java  
*  (c) 2002-2008 Juergen Nagel, Northwest German Research Station, 
*      Gr�tzelstr.2, 37079 G�ttingen, Germany
*      E-Mail: Juergen.Nagel@nw-fva.de
*
*  This program is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public License
*  as published by the Free Software Foundation.
*
*  This program is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*/
package treegross.base;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.ProcessingInstruction;
import org.jdom.output.XMLOutputter;
import org.jdom.input.*;
import org.jdom.DocType;
import java.net.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.*;
import java.util.*;
/** TreeGrOSS : TreegrossXML2.java
 *  version 	7.5 2-Oct-2008
 *  author	Juergen Nagel
 * 
 * This is the 2nd format to define a forest stand by XML. The class can read
 * and write a treegross xml file
 *  
 *  http://www.nw-fva.de/~nagel/treegross/
 *   
 */
public class TreegrossXML2 {
    static Document doc;
    static Element rootElt;
    
    /**
     * Creates a new instance of TreegrossXML2
     */
    public TreegrossXML2() {
    }
    
    public void saveAsXML(Stand st,String filename) {
        NumberFormat f=NumberFormat.getInstance();
        f=NumberFormat.getInstance(new Locale("en","US"));
        f.setMaximumFractionDigits(2);
        f.setMinimumFractionDigits(2);
        Element elt;
        Element elt2;
/** Creates an Treegross xml */
        Document doc = new Document();
        rootElt = new Element("Bestand");
        ProcessingInstruction pi = new ProcessingInstruction("xml-stylesheet",
                 "type=\"text/xsl\" href=\"treegross.xsl\"");
         doc.addContent(pi);
        doc.setRootElement(rootElt);
         
//         
/* Bestandesinformation */
        rootElt= addString(rootElt, "Id","1");
        rootElt= addString(rootElt, "Kennung",st.standname);
        rootElt= addString(rootElt, "Allgemeines"," ");
        rootElt= addString(rootElt, "Flaechengroesse_m2",new Double(st.size*10000).toString());
        rootElt= addString(rootElt, "HauptbaumArtCodeStd",new Integer(st.sp[0].code).toString());
        rootElt= addString(rootElt, "HauptbaumArtCodeLokal",new Integer(st.sp[0].code).toString());
        rootElt= addString(rootElt, "AufnahmeJahr",new Integer(st.year).toString());
        rootElt= addString(rootElt, "AufnahmeMonat",new Integer(st.monat).toString());
        rootElt= addString(rootElt, "DatenHerkunft",st.datenHerkunft);
        rootElt= addString(rootElt, "Standort",st.standort);
        rootElt= addString(rootElt, "Hochwert_m",new Double(st.hochwert_m).toString());
        rootElt= addString(rootElt, "Rechtswert_m",new Double(st.rechtswert_m).toString());
        rootElt= addString(rootElt, "Hoehe_uNN_m",new Double(st.hoehe_uNN_m).toString());
        rootElt= addString(rootElt, "Exposition_Gon",new Integer(st.exposition_Gon).toString());
        rootElt= addString(rootElt, "Hangneigung_Prozent",new Double(st.hangneigungProzent).toString());
        rootElt= addString(rootElt, "Wuchsgebiet",st.wuchsgebiet);
        rootElt= addString(rootElt, "Wuchsbezirk",st.wuchsbezirk);
        rootElt= addString(rootElt, "Standortskennziffer",st.standortsKennziffer);
        
/* Baumarten */;
        for (int i=0;i< st.nspecies;i++){
            elt = new Element("Baumartencode");
            elt= addString(elt, "Code",new Integer(st.sp[i].code).toString());
            elt= addString(elt, "deutscherName",st.sp[i].spDef.longName);
            elt= addString(elt, "lateinischerName",st.sp[i].spDef.latinName);
            rootElt.addContent(elt);
        }
/* Add center points */;
        elt = new Element("Eckpunkt");
        elt= addString(elt, "Nr",st.center.no);
        elt= addString(elt, "RelativeXKoordinate_m",f.format(st.center.x));
        elt= addString(elt, "RelativeYKoordinate_m",f.format(st.center.y));
        elt= addString(elt, "RelativeBodenhoehe_m",f.format(st.center.z));
        rootElt.addContent(elt);
        
/* Add corner points */;
        for (int i=0;i< st.ncpnt;i++){
            elt = new Element("Eckpunkt");
            elt= addString(elt, "Nr",st.cpnt[i].no);
            elt= addString(elt, "RelativeXKoordinate_m",f.format(st.cpnt[i].x));
            elt= addString(elt, "RelativeYKoordinate_m",f.format(st.cpnt[i].y));
            elt= addString(elt, "RelativeBodenhoehe_m",f.format(st.cpnt[i].z));
            rootElt.addContent(elt);
        }
/* Add B�ume */;
        for (int i=0;i< st.ntrees;i++){
            System.out.println("test "+i);
            elt= new Element("Baum");
            elt= addString(elt, "Nr",new Integer(i+1).toString());
            elt= addString(elt, "Kennung",st.tr[i].no);
            elt= addString(elt, "BaumartcodeStd","0");
            elt= addString(elt, "BaumartcodeLokal",new Integer(st.tr[i].code).toString());
            elt= addString(elt, "Alter_Jahr",new Integer(st.tr[i].age).toString());
            elt= addString(elt, "BHD_mR_cm",f.format(st.tr[i].d));
            elt= addString(elt, "Hoehe_m",f.format(st.tr[i].h));
            elt= addString(elt, "Kronenansatz_m",f.format(st.tr[i].cb));
            elt= addString(elt, "MittlererKronenDurchmesser_m",f.format(st.tr[i].cw));
            elt= addString(elt, "SiteIndex_m",f.format(st.tr[i].si));
            elt= addString(elt, "RelativeXKoordinate_m",f.format(st.tr[i].x));
            elt= addString(elt, "RelativeYKoordinate_m",f.format(st.tr[i].y));
            elt= addString(elt, "RelativeBodenhoehe_m",f.format(st.tr[i].z));
            boolean lebend=true;
            if (st.tr[i].out > -1) 
                lebend=false;
            elt= addString(elt, "Lebend",new Boolean(lebend).toString());
            boolean entnommen=false;
            if (st.tr[i].outtype >= 2) entnommen=true;
            elt= addString(elt, "Entnommen",new Boolean(lebend).toString());
            elt= addString(elt, "AusscheideMonat","3");
            elt= addString(elt, "AusscheideJahr",new Integer(st.tr[i].out).toString());
            String grund = "";
            if (st.tr[i].outtype == 1) grund="Mortalit�t";
            if (st.tr[i].outtype == 2) grund="Durchforstung";
            if (st.tr[i].outtype == 3) grund="Ernte";
            if (st.tr[i].outtype > 3)  grund="anderer";
            elt= addString(elt, "AusscheideGrund",grund);
            elt= addString(elt, "ZBaum",new Boolean(st.tr[i].crop).toString());
            elt= addString(elt, "ZBaumtemporaer",new Boolean(st.tr[i].tempcrop).toString());
            elt= addString(elt, "HabitatBaum",new Boolean(st.tr[i].habitat).toString());
            elt= addString(elt, "KraftscheKlasse","0");
            elt= addString(elt, "Schicht",new Integer(st.tr[i].layer).toString());
            f.setMaximumFractionDigits(4);
            f.setMinimumFractionDigits(4);
            elt= addString(elt, "Flaechenfaktor",f.format(st.tr[i].fac));
            elt= addString(elt, "Volumen_cbm",f.format(st.tr[i].v));
//            elt= addString(elt, "VolumenEntnommen_cbm",f.format(st.tr[i].z));
            elt= addString(elt, "VolumenTotholz_cbm",f.format(st.tr[i].volumeDeadwood));
            elt= addString(elt, "Bemerkung",st.tr[i].remarks);
            f.setMaximumFractionDigits(2);
            f.setMinimumFractionDigits(2);
            rootElt.addContent(elt);
        }
/* Abspeichern des doc */
        try {
            File file = new File(filename);
            FileOutputStream result = new FileOutputStream(file);
            XMLOutputter outputter = new XMLOutputter();
//            outputter.setNewlines(true);
//            outputter.setIndent("  ");
            outputter.output(doc,result);
                        
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
    public treegross.base.Stand readTreegrossStand(treegross.base.Stand stl, URL url){
       Stand st = new Stand();
       st=stl;
       try {
         SAXBuilder builder = new SAXBuilder();
         URLConnection urlcon = url.openConnection();

         Document doc = builder.build(urlcon.getInputStream());
//         Document doc = builder.build(filename);
           
         DocType docType = doc.getDocType();
//        
         Element bestand =  doc.getRootElement();  
         st.id = bestand.getChild("Id").getText();
         st.addName(bestand.getChild("Kennung").getText());
         st.addsize(Double.parseDouble(bestand.getChild("Flaechengroesse_m2").getText())/10000.0);
         st.monat = Integer.parseInt(bestand.getChild("AufnahmeMonat").getText());
         st.year=Integer.parseInt(bestand.getChild("AufnahmeJahr").getText());
         st.datenHerkunft = bestand.getChild("DatenHerkunft").getText();
         st.standort = bestand.getChild("Standort").getText();
         st.rechtswert_m = Double.parseDouble(bestand.getChild("Rechtswert_m").getText());
         st.hochwert_m = Double.parseDouble(bestand.getChild("Hochwert_m").getText());
         st.hoehe_uNN_m = Double.parseDouble(bestand.getChild("Hoehe_uNN_m").getText());
         st.exposition_Gon = Integer.parseInt(bestand.getChild("Exposition_Gon").getText());
         st.hangneigungProzent = Double.parseDouble(bestand.getChild("Hangneigung_Prozent").getText());
         st.wuchsgebiet = bestand.getChild("Wuchsgebiet").getText();
         st.wuchsbezirk = bestand.getChild("Wuchsbezirk").getText();
         st.standortsKennziffer = bestand.getChild("Standortskennziffer").getText();
         
//
         st.ncpnt=0;
         st.ntrees=0;
         st.nspecies=0;
         st.center.no="undefined";
         List eckpunkte = bestand.getChildren("Eckpunkt");
         Iterator i = eckpunkte.iterator();
         while (i.hasNext()) {
            Element eckpunkt = (Element) i.next();
            String nrx = eckpunkt.getChild("Nr").getText();
            if (nrx.indexOf("circle") > -1 || nrx.indexOf("polygon") > -1){
               st.center.no=nrx;    
               st.center.x=Double.parseDouble(eckpunkt.getChild("RelativeXKoordinate_m").getText());
               st.center.y=Double.parseDouble(eckpunkt.getChild("RelativeYKoordinate_m").getText());
               st.center.z=Double.parseDouble(eckpunkt.getChild("RelativeBodenhoehe_m").getText());
            }
            else {
                st.addcornerpoint(eckpunkt.getChild("Nr").getText(),
                   Double.parseDouble(eckpunkt.getChild("RelativeXKoordinate_m").getText()),
                   Double.parseDouble(eckpunkt.getChild("RelativeYKoordinate_m").getText()),
                   Double.parseDouble(eckpunkt.getChild("RelativeBodenhoehe_m").getText()));
            }
         } 
//         
         List baeume = bestand.getChildren("Baum");
         i = baeume.iterator();
         while (i.hasNext()) {
            Element baum = (Element) i.next();
            int out = -1 ;
            if (Boolean.parseBoolean(baum.getChild("Entnommen").getText())==false)
                out = Integer.parseInt(baum.getChild("AusscheideJahr").getText());
            int outtype=0;
            String ausGrund = baum.getChild("AusscheideGrund").getText();
            if (ausGrund.indexOf("Mort")>-1) outtype=1;
            if (ausGrund.indexOf("Durch")>-1) outtype=2;

            st.addXMLTree (Integer.parseInt(baum.getChild("BaumartcodeLokal").getText()),
                    baum.getChild("Kennung").getText(),
                    Integer.parseInt(baum.getChild("Alter_Jahr").getText()),
                    out, outtype,
                    Double.parseDouble(baum.getChild("BHD_mR_cm").getText()),
                    Double.parseDouble(baum.getChild("Hoehe_m").getText()),
                    Double.parseDouble(baum.getChild("Kronenansatz_m").getText()),
                    Double.parseDouble(baum.getChild("MittlererKronenDurchmesser_m").getText()),
                    Double.parseDouble(baum.getChild("SiteIndex_m").getText()),
                    Double.parseDouble(baum.getChild("Flaechenfaktor").getText()),
                    Double.parseDouble(baum.getChild("RelativeXKoordinate_m").getText()),
                    Double.parseDouble(baum.getChild("RelativeYKoordinate_m").getText()),
                    Double.parseDouble(baum.getChild("RelativeBodenhoehe_m").getText()),
                    Boolean.parseBoolean(baum.getChild("ZBaum").getText()),
                    Boolean.parseBoolean(baum.getChild("ZBaumtemporaer").getText()),
                    Boolean.parseBoolean(baum.getChild("HabitatBaum").getText()),
                    Integer.parseInt(baum.getChild("Schicht").getText()),
                    Double.parseDouble(baum.getChild("VolumenTotholz_cbm").getText()),
                    baum.getChild("Bemerkung").getText()
                    );
         } 

       } catch (Exception e) {e.printStackTrace();}
       return st;
}

    
    
    
    Element addString(Element elt, String variable, String text){
            Element var = new Element(variable);
            var.addContent(text);  
            elt.addContent(var);
            return elt;
    }

    
}

