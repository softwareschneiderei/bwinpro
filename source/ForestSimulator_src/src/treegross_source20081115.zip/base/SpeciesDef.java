/* http://www.nw-fva.de
   Version 07-11-2008

   (c) 2002 Juergen Nagel, Northwest German Forest Research Station, 
       Gr�tzelstr.2, 37079 G�ttingen, Germany
       E-Mail: Juergen.Nagel@nw-fva.de
 
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT  WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
 */
package treegross.base;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.*;
import org.jdom.DocType;
import java.io.*;
import java.text.*;
import java.util.*;
import java.net.*;
import javax.swing.*;

public class SpeciesDef implements Comparable, Cloneable{
    public int code;
    public int internalCode;
    public String shortName;
    public String longName;
    public String latinName;
    public int codeGroup;
    public int handledLikeCode;
    public int heightCurve;
    public int taperFunction;
    public int crownType;
    public double criticalCrownClosure;
    public int maximumAge;
    public double targetDiameter;
    public double heightOfThinningStart;
    public int colorGreen, colorRed, colorBlue;
    public boolean defined=false;
    public String modelRegion="default";
    public String volumeFunctionXML="";
    public String uniformHeightCurveXML="";    
    public String diameterDistributionXML="";    
    public String crownwidthXML="";    
    public String crownbaseXML="";    
    public String siteindexXML="";    
    public String diameterIncrementXML=""; 
    public double diameterIncrementError =0.0;
    public String heightIncrementXML="";    
    public double heightIncrementError =0.0;
    public String heightVariationXML="";
    public String siteindexHeightXML="";
    public String potentialHeightIncrementXML="";
    public String maximumDensityXML="";
    public String moderateThinning="";
    public String colorXML="100,200,300";
    public String decayXML="";
    public String competitionXML="";
    public String ingrowthXML="";
    public String taperFunctionXML="";
    public String coarseRootBiomass="";
    public String smallRootBiomass="";
    public String fineRootBiomass="";
    public String totalRootBiomass="";

    private String filename="";

    /** Creates a new instance of Class */
    public SpeciesDef()
    {
    }
    
    public SpeciesDef clone(){
        SpeciesDef clone = new SpeciesDef();
        clone.code= new Integer(this.code);
        clone.shortName= new String(this.shortName);
        clone.longName= new String(this.longName);
        clone.latinName= new String(this.latinName);
        clone.codeGroup= new Integer(this.codeGroup);
        clone.handledLikeCode = new Integer(this.handledLikeCode);
        clone.heightCurve= new Integer(this.heightCurve);
        clone.taperFunction= new Integer(this.taperFunction);
        clone.crownType= new Integer(this.crownType);
        clone.criticalCrownClosure= new Double(this.criticalCrownClosure);
        clone.maximumAge= new Integer(this.maximumAge);
        clone.targetDiameter= new Double(this.targetDiameter);
        clone.heightOfThinningStart= new Double(this.heightOfThinningStart);
        clone.colorGreen= new Integer(this.colorGreen);
        clone.colorRed= new Integer(this.colorRed);
        clone.colorBlue= new Integer(this.colorBlue);
        clone.defined= new Boolean(this.defined);
        clone.modelRegion= new String(this.modelRegion); 
        return clone;
    }
    
    //Copares two assortments: the higher the price, the lower the assortment
    public int compareTo(Object o) 
    {
        if(code ==((SpeciesDef)o).code)
            return 1;
        else
            return 0;
    }
    
    
    
    void setDefined(boolean def) { defined=def;}
    
    public SpeciesDef loadSpeciesDefXML(int spcode, String Dir,String File){
        
        try {
            URL url =null;
            int m = Dir.toUpperCase().indexOf("FILE");
            int m2 = Dir.toUpperCase().indexOf("HTTP");
            String trenn =System.getProperty("file.separator");
            String fname=Dir+trenn+File;
            if ( m < 0 && m2 <0 ) fname="file:"+trenn+trenn+trenn+fname;
//            System.out.println("SpeciesDef: URL: "+fname);
            try {
                 url = new URL(fname);}
            catch (Exception e){ 
                    JTextArea about = new JTextArea("SpeciesDef file not found: "+fname);
                    JOptionPane.showMessageDialog(null, about, "About", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("SpeciesDef: File nicht gefunden: "+fname);}
         SAXBuilder builder = new SAXBuilder();
         URLConnection urlcon = url.openConnection();

         Document doc = builder.build(urlcon.getInputStream());
         
         DocType docType = doc.getDocType();
//        
         Element sortimente =  doc.getRootElement();  
         List Sortiment = sortimente.getChildren("SpeciesDefinition");
         Iterator i = Sortiment.iterator();
         
         while (i.hasNext()) {
            Element sortiment = (Element) i.next();
            int codex =Integer.parseInt(sortiment.getChild("Code").getText());
            handledLikeCode = Integer.parseInt(sortiment.getChild("HandledLikeCode").getText());
            
            if (codex == spcode){
              code=codex;
              shortName = sortiment.getChild("ShortName").getText();
              longName = sortiment.getChild("LongName").getText();
              latinName = sortiment.getChild("LatinName").getText();
              internalCode =Integer.parseInt(sortiment.getChild("InternalCode").getText());
              codeGroup =Integer.parseInt(sortiment.getChild("CodeGroup").getText());
              heightCurve =Integer.parseInt(sortiment.getChild("HeightCurve").getText());
              uniformHeightCurveXML = sortiment.getChild("UniformHeightCurveXML").getText();
              heightVariationXML = sortiment.getChild("HeightVariation").getText();
              diameterDistributionXML = sortiment.getChild("DiameterDistributionXML").getText();
              volumeFunctionXML = sortiment.getChild("VolumeFunctionXML").getText();
              crownwidthXML = sortiment.getChild("Crownwidth").getText();
              crownbaseXML = sortiment.getChild("Crownbase").getText();
              crownType =Integer.parseInt(sortiment.getChild("CrownType").getText());
              siteindexXML = sortiment.getChild("SiteIndex").getText();
              siteindexHeightXML = sortiment.getChild("SiteIndexHeight").getText();
              potentialHeightIncrementXML = sortiment.getChild("PotentialHeightIncrement").getText();
              heightIncrementXML = sortiment.getChild("HeightIncrement").getText();
              heightIncrementError = Double.parseDouble(sortiment.getChild("HeightIncrementError").getText());
              diameterIncrementXML = sortiment.getChild("DiameterIncrement").getText();
              diameterIncrementError = Double.parseDouble(sortiment.getChild("DiameterIncrementError").getText());
              maximumDensityXML =sortiment.getChild("MaximumDensity").getText();
              maximumAge =Integer.parseInt(sortiment.getChild("MaximumAge").getText());
              ingrowthXML = sortiment.getChild("Ingrowth").getText();
              decayXML = sortiment.getChild("Decay").getText();
              targetDiameter =Double.parseDouble(sortiment.getChild("TargetDiameter").getText());
              heightOfThinningStart =Double.parseDouble(sortiment.getChild("HeightOfThinningStart").getText());
              moderateThinning = sortiment.getChild("ModerateThinning").getText();
              colorXML = sortiment.getChild("Color").getText();
              competitionXML = sortiment.getChild("Competition").getText();
              taperFunctionXML = sortiment.getChild("TaperFunction").getText();
              coarseRootBiomass = sortiment.getChild("CoarseRootBiomass").getText();
              smallRootBiomass = sortiment.getChild("SmallRootBiomass").getText();
              fineRootBiomass = sortiment.getChild("FineRootBiomass").getText();
              totalRootBiomass = sortiment.getChild("TotalRootBiomass").getText();
              break;
            }
         } 
// if HandledLikeCode is different than load other species         
         if (handledLikeCode != spcode){
             i = Sortiment.iterator();
       
             while (i.hasNext()) {
                 Element sortiment = (Element) i.next();
                 int handledLike = Integer.parseInt(sortiment.getChild("HandledLikeCode").getText());
                 if (handledLikeCode == handledLike){
                    if (heightCurve < 0) heightCurve =Integer.parseInt(sortiment.getChild("HeightCurve").getText());
                    if (uniformHeightCurveXML.trim().length() < 1) uniformHeightCurveXML = sortiment.getChild("UniformHeightCurveXML").getText();
                    if (heightVariationXML.trim().length() < 1) heightVariationXML = sortiment.getChild("HeightVariation").getText();
                    if (diameterDistributionXML.trim().length() < 1) diameterDistributionXML = sortiment.getChild("DiameterDistributionXML").getText();
                    if (volumeFunctionXML.trim().length() < 1) volumeFunctionXML = sortiment.getChild("VolumeFunctionXML").getText();
                    if (crownwidthXML.trim().length() < 1) crownwidthXML = sortiment.getChild("Crownwidth").getText();
                    if (crownbaseXML.trim().length() < 1) crownbaseXML = sortiment.getChild("Crownbase").getText();
                    if (crownType < 0) crownType =Integer.parseInt(sortiment.getChild("CrownType").getText());
                    if (siteindexXML.trim().length() < 1) siteindexXML = sortiment.getChild("SiteIndex").getText();
                    if (siteindexHeightXML.trim().length() < 1) siteindexHeightXML = sortiment.getChild("SiteIndexHeight").getText();
                    if (potentialHeightIncrementXML.trim().length() < 1) potentialHeightIncrementXML = sortiment.getChild("PotentialHeightIncrement").getText();
                    if (heightIncrementXML.trim().length() < 1) heightIncrementXML = sortiment.getChild("HeightIncrement").getText();
                    if (heightIncrementError < 0) heightIncrementError = Double.parseDouble(sortiment.getChild("HeightIncrementError").getText());
                    if (diameterIncrementXML.trim().length() < 1) diameterIncrementXML = sortiment.getChild("DiameterIncrement").getText();
                    if (diameterIncrementError < 0) diameterIncrementError = Double.parseDouble(sortiment.getChild("DiameterIncrementError").getText());
                    if (maximumDensityXML.trim().length() < 1) maximumDensityXML =sortiment.getChild("MaximumDensity").getText();
                    if (maximumAge < 0) maximumAge =Integer.parseInt(sortiment.getChild("MaximumAge").getText());
                    if (ingrowthXML.trim().length() < 1) ingrowthXML = sortiment.getChild("Ingrowth").getText();
                    if (decayXML.trim().length() < 1) decayXML = sortiment.getChild("Decay").getText();
                    if (targetDiameter < 0) targetDiameter =Double.parseDouble(sortiment.getChild("TargetDiameter").getText());
                    if (heightOfThinningStart < 0) heightOfThinningStart =Double.parseDouble(sortiment.getChild("HeightOfThinningStart").getText());
                    if (moderateThinning.trim().length() < 1) moderateThinning = sortiment.getChild("ModerateThinning").getText();
                    if (colorXML.trim().length() < 1) colorXML = sortiment.getChild("Color").getText();
                    if (competitionXML.trim().length() < 1) competitionXML = sortiment.getChild("Competition").getText();
                    if (taperFunctionXML.trim().length() < 1) taperFunctionXML = sortiment.getChild("TaperFunction").getText();
                    if (coarseRootBiomass.trim().length() < 1) coarseRootBiomass = sortiment.getChild("CoarseRootBiomass").getText();
                    if (smallRootBiomass.trim().length() < 1) smallRootBiomass = sortiment.getChild("SmallRootBiomass").getText();
                    if (fineRootBiomass.trim().length() < 1) fineRootBiomass = sortiment.getChild("FineRootBiomass").getText();
                    if (totalRootBiomass.trim().length() < 1) totalRootBiomass = sortiment.getChild("TotalRootBiomass").getText();
                   break;
                }
             } 

         }
              m = colorXML.indexOf(";");
              colorRed=Integer.parseInt(colorXML.substring(0,m));
              colorXML=colorXML.substring(m+1);
              m = colorXML.indexOf(";");
              colorGreen=Integer.parseInt(colorXML.substring(0,m));
              colorXML=colorXML.substring(m+1);
              colorBlue=Integer.parseInt(colorXML);
              setDefined(true);


       } catch (Exception e) {e.printStackTrace();}
  
        
        return this;
    } 
    
    public void listAllSpeciesDefinition(Stand st, String path, String fname){
            try
	    {
//	    System.out.println("Neuen Bericht erzeugen nach try");

		DecimalFormat f  = new DecimalFormat("0.00");
                File file= new File(path, fname);
                filename=file.getCanonicalPath();
                OutputStream os=new FileOutputStream(filename); 
		PrintWriter out= new PrintWriter(
			new OutputStreamWriter(os)); 
		out.println("<HTML>"); 
		out.println("<H2><P align=center>"+"Simulator Species Definition"+"</P align=center></H2> "); 
                for (int i=0;i<st.nspecies;i++){
                      out.println("<P> </P>"); 
                      int m = -9;
                      if (st.sp[i].spDef.latinName.indexOf("http") > -1) m = st.sp[i].spDef.latinName.indexOf("http")-1;
                      String txt= st.sp[i].spDef.latinName;
                      if (m > 1) txt = "<a href="+st.sp[i].spDef.latinName.substring(m+1,st.sp[i].spDef.latinName.length())+">"+st.sp[i].spDef.latinName.substring(0,m)+"</a>";
                      out.println("<P><B>Baumart: "+st.sp[i].code+" "+st.sp[i].spDef.longName+"  "+txt+"</B>"); 
                      out.println("<BR>   Kronenbreite [m] = "+st.sp[i].spDef.crownwidthXML); 
                      out.println("<BR>   Kronenansatz [m] = "+st.sp[i].spDef.crownbaseXML); 
                      out.println("<BR>   Bonit�t      [m] = "+st.sp[i].spDef.siteindexXML); 
                      out.println("<BR>   Potentielle H�henzuwachs [%] = "+st.sp[i].spDef.potentialHeightIncrementXML); 
                      out.println("<BR>   H�henzuwachsmodulation [%] = "+st.sp[i].spDef.heightIncrementXML); 
                      out.println("<BR>   Standardabweichung H�henzuwachs [m] = "+(new Double(st.sp[i].spDef.heightIncrementError)).toString()); 
                      out.println("<BR>   Grundfl�chenzuwachs [cm�] = "+st.sp[i].spDef.diameterIncrementXML); 
                      out.println("<BR>   Standardabweichung Grundfl�chenzuwachs [m�] = "+(new Double(st.sp[i].spDef.diameterIncrementError)).toString()); 
                      out.println("<BR>   Maximale Dichte [m�/ha] = "+st.sp[i].spDef.maximumDensityXML); 
                      out.println("<BR>   Volumenfunktion [m�] = "+st.sp[i].spDef.volumeFunctionXML); 
                      out.println("<BR>   Durchmesserverteilung : "+st.sp[i].spDef.diameterDistributionXML); 
                      out.println("<BR>   H�henkurvenfunktion = "+st.sp[i].spDef.heightCurve); 
                      out.println("<BR>   Einheitsh�henkurve [m] = "+st.sp[i].spDef.uniformHeightCurveXML); 
                      out.println("<BR>   H�henkurvenvariation [m] = "+st.sp[i].spDef.heightVariationXML); 
                      out.println("<BR>   Totholzzerfall [%] = "+st.sp[i].spDef.decayXML); 
                      out.println("<BR>   Kronendarstellung = "+st.sp[i].spDef.crownType); 
                      out.println("<BR>   Baumartenfarbe [RGB] = "+st.sp[i].spDef.colorXML); 
                      out.println("</P>"); 
                 }

                //      ss defined to write " 
		//String ss;
		//char c=34;
		//ss=String.valueOf(c);
              
		out.println("</TABLE>"); 
		out.println("<br>"+"created by ForestSimulatorBWINPro "+st.modelRegion+"</br></HTML>"); 
		out.close();
		}
		catch (Exception e)
		{	System.out.println(e); 
		} 
    
    }
    public void listSpeciesCode( String Dir, String File, String path, String fname2){
        try {
            URL url =null;
            int m = Dir.toUpperCase().indexOf("FILE");
            int m2 = Dir.toUpperCase().indexOf("HTTP");
            String trenn =System.getProperty("file.separator");
            String fname=Dir+trenn+File;
            if ( m < 0 && m2 <0 ) fname="file:"+trenn+trenn+trenn+fname;
//            System.out.println("SpeciesDef: URL: "+fname);
            try {
                 url = new URL(fname);}
            catch (Exception e){ 
                    JTextArea about = new JTextArea("SpeciesDef file not found: "+fname);
                    JOptionPane.showMessageDialog(null, about, "About", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("SpeciesDef: File nicht gefunden: "+fname);}
         SAXBuilder builder = new SAXBuilder();
         URLConnection urlcon = url.openConnection();
//
// Outputfile
//
	DecimalFormat f  = new DecimalFormat("0.00");
        File file= new File(path, fname2);
        filename=file.getCanonicalPath();
        OutputStream os=new FileOutputStream(filename); 
	PrintWriter out= new PrintWriter(
	new OutputStreamWriter(os)); 
	out.println("<HTML>"); 
	out.println("<H2><P align=center>"+"Species Code"+"</P align=center></H2><P> "); 
         
//         

         Document doc = builder.build(urlcon.getInputStream());
         
         DocType docType = doc.getDocType();
//        
         Element sortimente =  doc.getRootElement();  
         List Sortiment = sortimente.getChildren("SpeciesDefinition");
         Iterator i = Sortiment.iterator();
         
         while (i.hasNext()) {
            Element sortiment = (Element) i.next();
            int codex =Integer.parseInt(sortiment.getChild("Code").getText());
              code=codex;
              shortName = sortiment.getChild("ShortName").getText();
              longName = sortiment.getChild("LongName").getText();
              latinName = sortiment.getChild("LatinName").getText();
              internalCode =Integer.parseInt(sortiment.getChild("InternalCode").getText());
              codeGroup =Integer.parseInt(sortiment.getChild("CodeGroup").getText());
              int mm = -9;  
              if (latinName.indexOf("http") > -1) mm = latinName.indexOf("http")-1;
              String txt= latinName;
              if (mm > 1) txt = "<a href="+latinName.substring(mm+1,latinName.length())+">"+latinName.substring(0,mm)+"</a>";
              out.println("<BR>Baumart: "+code+" "+shortName+" "+longName+"  "+txt+""); 

         } 


	out.println("</P></TABLE>"); 
	out.println("<br>"+"created by ForestSimulatorBWINPro </br></HTML>"); 
	out.close();

       } catch (Exception e) {e.printStackTrace();}
  
        
            
    }
     public String getFilename() {
            return filename;
   }
    
}
