/* http://www.nw-fva.de
   Version 07-11-2008

   (c) 2002 Juergen Nagel, Northwest German Forest Research Station, 
       Gr�tzelstr.2, 37079 G�ttingen, Germany
       E-Mail: Juergen.Nagel@nw-fva.de
 
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT  WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
 */
package treegross.base;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.*;
import org.jdom.DocType;
import java.util.*;
import java.net.*;
import java.io.*;


/**
 *
 * @author J. Nagel
 * This modul calculates a) the amount of wood harvested, b) the deadwood 
 * and c) nature conservation conservation relevant deadwood
 * For this the files deadwoodSortiment.xml and standardSortiment.xml are needed
 * 
 */
public class DeadwoodModulNWFVA {
    Stand st = null;   
    Assortment dws[] = new Assortment[100];  
    Assortment sts[] = new Assortment[500];  
    int ndws = 0;
    int nsts = 0;
    URL url = null;
    
    public void start(Stand stx){
        st = stx;
        JSortiererNFV sortierer = new JSortiererNFV(st.sp[0].spDef.taperFunctionXML);

// load Assortments from files
        String fname=st.programDir+System.getProperty("file.separator")+"deadwoodSortiment.xml";
        int m = st.programDir.toUpperCase().indexOf("FILE");
        int m2 =st.programDir.toUpperCase().indexOf("HTTP");
        if ( m < 0 && m2 <0 ) fname="file:"+System.getProperty("file.separator")
                +System.getProperty("file.separator")+System.getProperty("file.separator")+fname;
        try{
          URL url = new URL(fname);
          loadDWS(url);
        }
        catch (IOException e){
            e.printStackTrace();
        }
        fname=st.programDir+System.getProperty("file.separator")+"standardSortiment.xml";
        m = st.programDir.toUpperCase().indexOf("FILE");
        m2 =st.programDir.toUpperCase().indexOf("HTTP");
        if ( m < 0 && m2 <0 ) fname="file:"+System.getProperty("file.separator")
                +System.getProperty("file.separator")+System.getProperty("file.separator")+fname;
        try{
          URL url = new URL(fname);
          loadSTS(url);
        }
        catch (IOException e){
            e.printStackTrace();
        }
        

//
        
        for (int i=0; i < st.ntrees; i++)
            if (st.tr[i].out == st.year) {
// Entnahme berechnen 
                double startHeight=0.0;
                if (st.tr[i].outtype > 1){
//          alle ndws Sortimente durchlaufen
                   startHeight =0.3;
                   for (int j=0;j<nsts;j++) {
                       double ran = Math.random() * 100.0;
                       if (st.tr[i].code >= sts[j].artvon && st.tr[i].code <= sts[j].artbis && ran <= sts[j].wahrscheinlich){
                            boolean logFound = true;
                            double endHeight = st.tr[i].h;
                            if (sts[j].bisKronenansatz) endHeight = st.tr[i].cb;
                            boolean logOk = true;
                            if (sts[j].nurZBaum && st.tr[i].crop == false) logOk = false;
                            while(logFound && logOk) {
                               logFound = sortierer.getAssortment(st.tr[i].sp.spDef.taperFunction , st.tr[i].d, 1.3, 0.0, 0.0, st.tr[i].h,
                                    startHeight, endHeight, sts[j].minD, sts[j].maxD, sts[j].minTop, sts[j].maxTop,
                                    sts[j].minH, sts[j].maxH, 0.0, sts[j].zugabeProzent, sts[j].zugabeCm);
                               if(logFound) {
// volume calculate according to function
                                   double length_m = startHeight;
                                   length_m = sortierer.getALae_m();
                                   double voldws = 0.0;
                                   voldws = sortierer.getAVolmR_m3(); 
                                   st.tr[i].volumeHarvested=st.tr[i].volumeHarvested+voldws;
                                   startHeight=startHeight + length_m;
                                       
                                }
                               if (sts[j].mehrfach == false) logFound = false; //Abbruch
                            }// while log found
                        }
                       }//end all assortments
                } //outtype > 1
//                
// Mortality trees in deadwood
                st.tr[i].volumeDeadwood = st.tr[i].v - st.tr[i].volumeHarvested;
                if (st.tr[i].volumeDeadwood < 0.0) st.tr[i].volumeDeadwood =0.0;
// Get nature protection relevant deadwood
// alle ndws Sortimente durchlaufen
                       
                       for (int j=0;j<ndws;j++) {
                          double ran = Math.random() * 100.0;
                          if (st.tr[i].code >= dws[j].artvon && st.tr[i].code <= dws[j].artbis && ran <= dws[j].wahrscheinlich){
                            boolean logFound = true;
                            double endHeight = st.tr[i].h;
                            if (dws[j].bisKronenansatz) endHeight = st.tr[i].cb;
                            boolean logOk = true;
                            if (dws[j].nurZBaum && st.tr[i].crop == false) logOk = false;
                            while(logFound && logOk) {
                               logFound = sortierer.getAssortment(st.tr[i].sp.spDef.taperFunction , st.tr[i].d, 1.3, 0.0, 0.0, st.tr[i].h,
                                    startHeight, endHeight, dws[j].minD, dws[j].maxD, dws[j].minTop, dws[j].maxTop,
                                    dws[j].minH, dws[j].maxH, 0.0, dws[j].zugabeProzent, dws[j].zugabeCm);
                                if(logFound) {
// volume calculate according to function
                                   double length_m = startHeight;
                                   length_m = sortierer.getALae_m();
                                   double voldws = 0.0;
                                   voldws = sortierer.getAVolmR_m3(); 
                                   st.tr[i].volumeDeadwoodConservation=st.tr[i].volumeDeadwoodConservation+voldws;
                                   startHeight=startHeight + length_m;
                                       
                                }
                               if (dws[j].mehrfach == false) logFound = false; //Abbruch
                            }// while log found
                        }
                       }//end all assortments
                         
// end of all trees                          
            }
        
// Totholzzerfall
        for (int i=0; i < st.ntrees; i++)
            if (st.tr[i].out > 0) {
                double fac=1.0-((st.year-5.0-st.tr[i].out-5.0)/30.0);
                if (fac > 1.0 ) fac=1.0;
                if (fac < 0.0 ) fac=0.0;
                double fac2=1.0-((st.year-st.tr[i].out-5.0)/30.0);
                if (fac2 > 1.0 ) fac2=1.0;
                if (fac2 < 0.0 ) fac2=0.0;
                if (fac > 0) st.tr[i].volumeDeadwood = fac2*st.tr[i].volumeDeadwood/fac;           
                if (fac > 0) st.tr[i].volumeDeadwoodConservation = fac2*st.tr[i].volumeDeadwoodConservation/fac;           
            }

        
        
        double totalvolume =0.0;
        double totalnsvolume =0.0;
        double totalhvvolume =0.0;
        for (int i=0; i < st.ntrees; i++){
            totalvolume = totalvolume+ st.tr[i].volumeDeadwood * st.tr[i].fac/st.size;
            totalnsvolume = totalnsvolume+ st.tr[i].volumeDeadwoodConservation* st.tr[i].fac/st.size;
            totalhvvolume = totalhvvolume+ st.tr[i].volumeHarvested* st.tr[i].fac/st.size;
        }
            
        System.out.println("Totholz: "+totalvolume+"   "+totalnsvolume+"   "+totalhvvolume);
        
    }
        
    private void loadDWS(URL url){
        ndws=0;
        try {
         SAXBuilder builder = new SAXBuilder();
         URLConnection urlcon = url.openConnection();

         Document doc = builder.build(urlcon.getInputStream());
         
         DocType docType = doc.getDocType();
//        
         Element sortimente =  doc.getRootElement();  
         List Sortiment = sortimente.getChildren("Sortiment");
         Iterator i = Sortiment.iterator();
         
         while (i.hasNext()) {
            Element sortiment = (Element) i.next();
            dws[ndws] = new Assortment(sortiment.getChild("Name").getText(),
                    Integer.parseInt(sortiment.getChild("Art_von").getText()),Integer.parseInt(sortiment.getChild("Art_bis").getText()),
                    Double.parseDouble(sortiment.getChild("minD").getText()),Double.parseDouble(sortiment.getChild("maxD").getText()),
                    Double.parseDouble(sortiment.getChild("minTop").getText()),Double.parseDouble(sortiment.getChild("maxTop").getText()),
                    Double.parseDouble(sortiment.getChild("minH").getText()),Double.parseDouble(sortiment.getChild("maxH").getText()),
                    Double.parseDouble(sortiment.getChild("ZugabeProzent").getText()),Double.parseDouble(sortiment.getChild("ZugabeCm").getText()),
                    Double.parseDouble(sortiment.getChild("Preis").getText()),Double.parseDouble(sortiment.getChild("Gewicht").getText()),
                    Double.parseDouble(sortiment.getChild("Wahrscheinlichkeit").getText()),
                    Boolean.parseBoolean(sortiment.getChild("nurZBaum").getText()),
                    Boolean.parseBoolean(sortiment.getChild("mehrfach").getText()),
                    Boolean.parseBoolean(sortiment.getChild("Entnahme").getText()),
                    Boolean.parseBoolean(sortiment.getChild("bisKA").getText()),
                    Boolean.parseBoolean(sortiment.getChild("ausgewaehlt").getText()),
                    ndws
                    );
            ndws = ndws +1;
         } 

       } catch (Exception e) {e.printStackTrace();}
       
}     
        
    private void loadSTS(URL url){
        nsts=0;
        try {
         SAXBuilder builder = new SAXBuilder();
         URLConnection urlcon = url.openConnection();

         Document doc = builder.build(urlcon.getInputStream());
         
         DocType docType = doc.getDocType();
//        
         Element sortimente =  doc.getRootElement();  
         List Sortiment = sortimente.getChildren("Sortiment");
         Iterator i = Sortiment.iterator();
         
         while (i.hasNext()) {
            Element sortiment = (Element) i.next();
            sts[nsts] = new Assortment(sortiment.getChild("Name").getText(),
                    Integer.parseInt(sortiment.getChild("Art_von").getText()),Integer.parseInt(sortiment.getChild("Art_bis").getText()),
                    Double.parseDouble(sortiment.getChild("minD").getText()),Double.parseDouble(sortiment.getChild("maxD").getText()),
                    Double.parseDouble(sortiment.getChild("minTop").getText()),Double.parseDouble(sortiment.getChild("maxTop").getText()),
                    Double.parseDouble(sortiment.getChild("minH").getText()),Double.parseDouble(sortiment.getChild("maxH").getText()),
                    Double.parseDouble(sortiment.getChild("ZugabeProzent").getText()),Double.parseDouble(sortiment.getChild("ZugabeCm").getText()),
                    Double.parseDouble(sortiment.getChild("Preis").getText()),Double.parseDouble(sortiment.getChild("Gewicht").getText()),
                    Double.parseDouble(sortiment.getChild("Wahrscheinlichkeit").getText()),
                    Boolean.parseBoolean(sortiment.getChild("nurZBaum").getText()),
                    Boolean.parseBoolean(sortiment.getChild("mehrfach").getText()),
                    Boolean.parseBoolean(sortiment.getChild("Entnahme").getText()),
                    Boolean.parseBoolean(sortiment.getChild("bisKA").getText()),
                    Boolean.parseBoolean(sortiment.getChild("ausgewaehlt").getText()),
                    nsts
                    );
            nsts = nsts +1;
         } 

       } catch (Exception e) {e.printStackTrace();}
        
       // Logging Sortimente nach Priorit�t  sortieren
       for(int i=0; i<nsts; i++)sts[i].ausgewaehlt=true; 
       Assortment temp = new Assortment();
        for (int i=0;i< nsts-1;i++)
           for (int j=i+1;j< nsts;j++)
               if (sts[j].gewicht < sts[i].gewicht) {
                   temp=sts[i];
                   sts[i]=sts[j];
                   sts[j]=temp;
               }
 
       
}    
    

}
