/*
 * Treatment2.java
 *
 *  (c) 2002-2006 Juergen Nagel, Northwest German Forest Research Station, 
 *      Gr�tzelstr.2, 37079 G�ttingen, Germany
 *      E-Mail: Juergen.Nagel@nw-fva.de
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  http://treegross.sourceforge.net
 */

package treegross.treatment;
import treegross.base.*;


/**
 * @author	Henriette Duda 
 * for more information see:
 * Duda, H. (2006): Vergleich forstlicher Managementstrategien. 
 * Dissertation Universit�t G�ttingen, S. 180 
 * http://webdoc.sub.gwdg.de/diss/2006/duda/ 
 */
public class Treatment2 {
    
    TreatmentElements2 te =new TreatmentElements2();
    Layer layer=new Layer();
    
    
    
    /** performs a stand treatment according to user defined preferences
     * this is  a regesigned rotutine from Henriette Duda's treatment
     * @param st stand object
     */ 
    public void executeManager2(Stand st){

        st.sortbyd();
        st.descspecies();

        //set min outVolume (lowest)
        if (st.trule.minHarvestVolume<=st.trule.minThinningVolume){
            st.trule.minOutVolume=st.trule.minHarvestVolume;
        }
        else{
            st.trule.minOutVolume=st.trule.minThinningVolume;
        }
        //set max outVolume (highest)
        if (st.trule.maxHarvestVolume>=st.trule.maxThinningVolume){
            st.trule.maxOutVolume=st.trule.maxHarvestVolume;
        }
        else{
            st.trule.maxOutVolume=st.trule.maxThinningVolume;
        }

        // reset amount of volume taken out 
        // only, if this treatment takes place at least one year after last treatment
        if (st.year>st.trule.lastTreatment){
            //vout, thinned, harvested is set =0
            te.resetOutTake(st);
        }
//
// create skidtrails, this is only done once        
//        
        if (st.trule.skidtrails) te.createSkidtrails(st);
 
        // do treatment, 
        // if actual year > year of last treatment + treatment step
        // or if actual year is the same as year of last treatment
        if (st.year>=st.trule.lastTreatment+st.trule.treatmentStep || st.year==st.trule.lastTreatment){
            
 // Nature protection block
 // 1. crop tree per species to protect minorities
 // 2. habitat tree           
 //           
            // Start minority selection, by choosing one crop tree per species 
            if (st.trule.protectMinorities==true){
                //protect minoritys (select one tree per species)                
                te.SelectOneCropTreePerSpecies(st, false); 
            }
            
            if (st.trule.nHabitat>0){
                //habitat trees are selected, habitat trees can not be harvested or chosen as
                // crop trees                
                te.selectHabitatTrees(st);
            }
// Harvesting block
//            

            if (st.trule.typeOfHarvest==0){
                // target diameter trees are harvested
                te.harvestTargetDiameter(st);        
            }


            if (st.trule.typeOfHarvest==2){    
                if (st.trule.harvestLayerFromBelow==false){
                    // trees> max age are harvested
                    te.harvestTargetAgeFromAbove(st) ;
                }
                else te.harvestTargetAgeFromBelow(st);
            }

  
            if (st.trule.typeOfHarvest==1){  
                //start of harvest if dg of upper layer> target dg
                //harvest rest of layer with ending of harvesting periode
                if (st.trule.harvestLayerFromBelow==false){
                    //start taking out trees from above
                    te.harvestTargetDgFromAbove(st); 
                }
                //start taking out trees from below
                else te.harvestTargetDgFromBelow(st); 
            }
// Perform a Schirmschlag, if 30% of trees reach target diameter            
            if (st.trule.typeOfHarvest==8){  
                te.harvestSchirmschlag(st); 
            }


// Perform a clearcut, if 30% of trees reach target diameter            
            if (st.trule.typeOfHarvest==9){  
                te.harvestClearCut(st); 
            }

            if (st.trule.cutCompetingCropTrees==true){
                //see if crop trees are competing with each other-> harvest crop tree
                te.harvestCompetingCropTrees(st); 
            } 

            //if harvest amount was not high enough: set harvested trees alive
            // this is when harvest amount is less than the minimum harvest volume
            // Idea: You do not bring in a machine for one tree
            te.checkMinHarvestVolume(st);
// Crop tree selection
//            
//
            // Selection and reselection of Crop Trees
            if (te.getNCropTrees(st)<=0 || st.trule.reselectCropTrees==true)
                {
                    // select defined number of crop trees
                    //number is reduced, depending on dg of leading layer
                    if (st.trule.selectCropTrees) te.selectNCropTrees(st);

                }
              
// Thinning by releasing the crop trees              
            if (st.trule.releaseCropTrees==true){
                te.thinCropTreeCompetition(st);               
                te.thinCompetitionFromAbove(st);
            }

            //all temp crop tree are deselected
            te.resetTempCropTrees(st); 


// Thinning from below              
            if (st.trule.typeOfThinning==2){
                te.thinFromBelow(st);               
            }

            // thin area between crop trees
// selectCropTreesOfAllSpecies auch hier einbeziehen?            
            //public double degreeOfThinningArea; 
            if (st.trule.thinArea==true){
                //select temp crop trees (wet species)
                te.selectTempCropTreesTargetPercentage(st);
                // Start thinning for all species
                te.thinTempCropTreeCompetition(st);
                te.thinCompetitionFromAbove(st);
            }       

            //if thinning amount was not high enough: set thinned trees alive
            te.checkMinThinningVolume(st);

            //if treatment amount was not high enough: set outtaken trees alive
            te.checkMinTreatmentOutVolume(st);
        }

            //if trees has been taken out this year
            if (te.getHarvestedOutVolume(st)>0 || te.getThinnedOutVolume(st)>0){
                st.trule.lastTreatment=st.year;
            }        
    }      

    
        
    /** stand is sorted by diameter and species are describes
     * @param st stand object
     */
    public void updateStandAfterThinning(Stand st){

        st.sortbyd();
        st.descspecies();        
    }
    
    /** unselct all (temp)croptrees
     * @param st stand object
     */
    public void resetAllCropTrees(Stand st){
        te.resetTempCropTrees(st);
        te.resetCropTrees(st);
        
    }   
    
    /**set default values according L�WE-Concept 
     * (needed by TgJFrame)*/
    public void setLoeweDefault(Stand st){   
        st.trule.treatmentType=0;
        st.trule.treatmentStep=10;        
        st.trule.maxHarvestVolume=70;
        st.trule.minHarvestVolume=10;
        st.trule.harvestingYears=0;        
        st.trule.maxHarvestingPeriode=999999999;
        st.trule.maxThinningVolume=30;
        st.trule.minThinningVolume=10;
        st.trule.maxOutVolume=st.trule.maxHarvestVolume;
        st.trule.minOutVolume=0;
        st.trule.nHabitat=1;
        st.trule.protectMinorities=true;    
        
        for (int i=0;i<st.nspecies; i++){
            st.sp[i].trule.targetCrownPercent=st.sp[i].percCSA;
            st.sp[i].trule.minCropTreeHeight=st.sp[i].spDef.heightOfThinningStart;
            st.sp[i].trule.maxAge=-999;
            st.sp[i].trule.targetDiameter=st.sp[i].spDef.targetDiameter;
            st.sp[i].trule.thinningIntensity=0;            
        }        
        
    }    

    

    
}



