package treegross.base;
import treegross.base.Stand;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author nagel
 */
public class LightCrown {
     Stand st =null;
     public LightCrown(Stand stand){
        st = stand; 
     }
     public void calcLightCrown(){
// f�r alle B�ume 
         double hx = 0.0;
         double hu = 0.0;
         double w =0.0;
         String mm = "";
         String mmm = "";
         boolean notouch = true;
         for (int i=0;i<st.ntrees;i++){
             hu = st.tr[i].h - 2.0*(st.tr[i].h-st.tr[i].cb)/3.0;
             String nrx =st.tr[i].no;
             double lKMF =0.0;
             double hmin = hu;
                          
// f�r 8 Radien             
             for (int j=0;j<8;j++){
// �ber alle Nachbarn pr�fen ob die Kronen sich ber�hren  
                 hmin = hu;
                 hx = st.tr[i].h ;
// Koordinate berechnen
                 double xp = st.tr[i].x;
                 double yp = st.tr[i].y;
                 notouch = true;
                 while (notouch && hx > hu){
// berechnen der Koordinate
                    hx =hx -0.01;
                    w = j* 50.0;
                    double cri = st.tr[i].calculateCwAtHeight(hx)/2.0;
                    xp=st.tr[i].x+Math.sin(Math.PI*w/200.0)*cri;
                    yp=st.tr[i].y+Math.cos(Math.PI*w/200.0)*cri;
                 
 // pr�fen ob ein Nachbar �ber den Punkt reicht
                    for (int k=0; k<st.tr[i].nNeighbor;k++){
                         mm = st.tr[st.tr[i].neighbor[k]].no;
                         double dx = st.tr[st.tr[i].neighbor[k]].x-xp;
                         double dy = st.tr[st.tr[i].neighbor[k]].y-yp;
                         double ent = Math.sqrt(Math.pow(dx, 2.0)+Math.pow(dy, 2.0));
// Radius des Konkurrenten                         
                         double crk = st.tr[st.tr[i].neighbor[k]].cw/2.0; 
                         if (hx >= st.tr[st.tr[i].neighbor[k]].h)crk = 0.0; 
                         if (hx <= st.tr[st.tr[i].neighbor[k]].cb)crk = st.tr[st.tr[i].neighbor[k]].cw/2.0; 
                         if (hx < st.tr[st.tr[i].neighbor[k]].h && hx > st.tr[st.tr[i].neighbor[k]].cb)
                                       crk = st.tr[st.tr[i].neighbor[k]].calculateCwAtHeight(hx)/2.0; 
// Abfrage, ob der Radius �ber den Punkt ragt                         
                         if (crk > ent){
                            notouch = false;
                            if (hmin < hx) hmin = hx;
                                mmm = mm;
                            }
                    }                          
                    
                 } // while ENDE
                 double crx = st.tr[i].cw/2.0;
                 if (hmin < st.tr[i].h && hmin > st.tr[i].cb) crx = st.tr[i].calculateCwAtHeight(hmin)/2.0; 
                 double lx = st.tr[i].h-hmin;
                 lKMF=lKMF+ 0.125*(Math.PI*crx/(6*lx*lx))*(Math.exp(Math.log(4*lx*lx+crx*crx)*1.5)-crx*crx*crx);
//               if (i < 9) System.out.println(nrx+"  "+j+"  "+ mmm + "  " + hmin+"  "+lKMF);    
            } // f�r 8 Radien
            st.tr[i].cwLightCrown=lKMF;
             
         } // f�r allle B�ume 
         
     } 
     
}
