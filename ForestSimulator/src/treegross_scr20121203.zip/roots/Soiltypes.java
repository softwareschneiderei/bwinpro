/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package treegross.roots;

/**
 *
 * @author nagel
 */
   public enum Soiltypes{
       Sand , Loam , Silt , Clay , Bedrock ;
   public int getLength(){
       return 5;
   }
}


