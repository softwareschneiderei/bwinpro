/* http://www.nw-fva.de
   Version 30 Juli 2010

   (c) 2010 Juergen Nagel, Northwest German Forest Research Station,
       Gr�tzelstr.2, 37079 G�ttingen, Germany
       E-Mail: Juergen.Nagel@nw-fva.de
 
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT  WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
 */
package treegross.harvesting;

/**
 *
 * @author nagel
 */
public class NutrientBalanceLine {
    
    int year=0;
    double cutVolume = 0.0;
    boolean sortiments = true;
    boolean firewood = true;
    boolean restwood = true;
    double firewoodPerc = 80.0;
    double restwoodPerc = 90.0;
    double needlePerc = 30.0;
    double sortimentsBM = 0.0;
    double barksortimentsBM=0.0;
    double barkfirewoodBM=0.0;
    double barkrestwoodBM=0.0;
    double branchBM=0.0;
    double reisigBM=0.0;
    double firewoodBM =0.0;
    double restwoodBM =0.0;
    double leafBM =0.0;
    double sumC=0.0;
    double sumN=0.0;
    double sumS=0.0;
    double sumP=0.0;
    double sumK=0.0;
    double sumCa=0.0;
    double sumMg=0.0;
    double sumMn=0.0;
    double sumFe=0.0;
    double sumBOup=0.0;
    double sumBNH4=0.0;
    double sumBNO3=0.0;

    
    
    /** Creates a new instance of LoggingSortiment */
    public NutrientBalanceLine() {
    }

    
}
